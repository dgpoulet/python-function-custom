def return_fortytwo():
    return 42